using System.Diagnostics;

namespace JnnBoost.Wpf.Services
{
    // Wrapper stub used by the WPF UI. Will be replaced by a Core implementation
    // when the real service is available and injected in App.OnStartup.
    public class OptimizerService : IOptimizerService
    {
        public void FPSBoost() => Debug.WriteLine("Stub: FPSBoost chamado.");
        public void GPUBoost() => Debug.WriteLine("Stub: GPUBoost chamado.");
        public void OptimizeRAM() => Debug.WriteLine("Stub: OptimizeRAM chamado.");
        public void CleanTemp() => Debug.WriteLine("Stub: CleanTemp chamado.");
        public void CleanNetwork() => Debug.WriteLine("Stub: CleanNetwork chamado.");
    }
}
