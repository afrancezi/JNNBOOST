namespace JnnBoost.Wpf
{
    public partial class App : System.Windows.Application
    {
        // Placeholder InitializeComponent for headless build environments.
        private void InitializeComponent() { }
    }
}
