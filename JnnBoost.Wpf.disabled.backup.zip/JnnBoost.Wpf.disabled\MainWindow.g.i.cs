namespace JnnBoost.Wpf
{
    public partial class MainWindow
    {
        // Placeholder generated method for headless build.
        private void InitializeComponent() { }
    }
}
