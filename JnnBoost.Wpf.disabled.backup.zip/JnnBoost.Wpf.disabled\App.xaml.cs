using System.Windows;

namespace JnnBoost.Wpf
{
    // Real WPF application partial class that matches App.xaml x:Class
    public partial class App : Application
    {
        public App()
        {
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Wire services (simple manual DI)
            var optimizer = new Services.OptimizerService();

            var mainWindow = new MainWindow();
            // Inject ViewModel with service
            mainWindow.DataContext = new ViewModels.MainViewModel(optimizer);
            mainWindow.Show();
        }
    }
}
