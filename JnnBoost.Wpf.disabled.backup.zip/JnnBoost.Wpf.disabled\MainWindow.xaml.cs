using JnnBoost.Wpf.ViewModels;
using System.Windows;

namespace JnnBoost.Wpf
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

    }

}
