// Interface local que delega para JnnBoost.Core.IOptimizerService quando disponível.
// Mantemos definição compatível para cenários onde a referência de projeto
// ainda não foi resolvida pelo build runner.
namespace JnnBoost.Wpf.Services
{
    public interface IOptimizerService
    {
        void FPSBoost();
        void GPUBoost();
        void OptimizeRAM();
        void CleanTemp();
        void CleanNetwork();
    }
}
