using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using JnnBoost.Wpf.Services;

namespace JnnBoost.Wpf.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly IOptimizerService optimizer;
        private string logText = "";
        public MainViewModel(IOptimizerService optimizer)
        {
            this.optimizer = optimizer;
            BoostCommand = new RelayCommand(() => { this.optimizer.FPSBoost(); AddLog("Boost acionado (stub)"); });
        }

        public ICommand BoostCommand { get; }

        public string LogText { get => logText; set { logText = value; OnPropertyChanged(); } }

        public void AddLog(string line)
        {
            LogText = (string.IsNullOrEmpty(LogText) ? "" : LogText + "\n") + $"[{System.DateTime.Now:HH:mm:ss}] {line}";
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}